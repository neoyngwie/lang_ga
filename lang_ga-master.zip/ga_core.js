﻿var scode="";
var tokens;
var buffer="";

function isOp(c){
	if(c==' ' || c=='\n' || c=='\r' || c=='\t'|| c=='+' || c=='-' || c=='{' || c=='}' || c=='(' || c==')' ||c=='*' || c=='/' || c=='=' || c=='>' || c=='<' ||c=='.' || c==','|| c=='"'){
		return true;
	}
	else return false;
}
function HELP(){
	alert("왼쪽에 쓴 내용 중 수식은 모두 흡입하여 계산 결과를 출력해 줍니다.");
}
function scanner(){
	var i=0;
	tokens=new Array();
  	var c;
	var state=0; //0이면 연산자 가리기 모드
				 //1이면 단어 만들기 모드
            //2이면 숫자 만들기 모드
	for(; i<scode.length; i++){
		c=scode.charAt(i);
		if(state==0){		
			if(c==' ' || c=='\r' || c=='\t'||c=='\n'){
				tokens.push(c);
				continue;
			}
			if(c=='"'){
				buffer='"';
				state=4;
				continue;
			}
			var nc=(i<scode.length-1)?scode.charAt(i+1):'@';
			if(c=='/'&&c=='/'){
				i++;
				state=3;
				continue;
			}
			if(c=='-' || c=='+' || c=='*' || c=='='){
				if(nc==c){
					tokens.push(c+c); // -- , ++ , ** , ==
					i++;
				}else if(nc=='='){
					tokens.push(c+'='); // -= , += , *= 
					i++;
				}else{
					tokens.push(c); // - , + , * , =
				}
			}else if(c=='>' || c=='<' || c=='/'){
				if(nc=='='){
					tokens.push(c+'='); // >= , <= , /=
					i++;
				}else{
					tokens.push(c); // > , < , /
				}
				continue;
			}else{
            	switch(c){
                	case '{': tokens.push(c); continue; // {
                	case '}': tokens.push(c); continue; // }
                	case '(': tokens.push(c); continue; // (
					case ')': tokens.push(c); continue; // )
					case '.': tokens.push(c); continue; // .
					case ',': tokens.push(c); continue; // ,
                	default:
				}
                if(isNaN(c)){
                	    state=1; buffer=c; // 연산자도 아니고 숫자도 아닌것이 시작됐다. 식별자(변수명, 함수명, 예약어 등 단어)의 시작
                }else{
                        state=2; buffer=c; // 숫자 추리기 시작
                }
			}
		}else if(state==1){
		    if(isOp(c)){
				i--;
				state=0;
				tokens.push(buffer);
				buffer="";
			}else{
				buffer+=c;
				if(i>=scode.length-1){
					tokens.push(buffer);
					buffer="";
				}
			}
		}else if(state==2){ 
			if(c!='.' && (isOp(c) || isNaN(c)) ){
				i--;
				state=0;
				tokens.push(parseFloat(buffer)); 
				buffer="";5
			}else{
				buffer+=c;
				if(i>=scode.length-1){
					tokens.push(parseFloat(buffer));
					buffer="";
				}
			}
		}else if(state==3){
			if(c=='\n'||c=='\r'){
				state=0;
			}
		}else if(state==4){
			if(c=='"'){
				buffer+='"';
				tokens.push(buffer);
				buffer="";
				state=0;
			}else{
				buffer+=c;
			}
		}
	}
}

function onClickRun(){
     scode=document.getElementById("sourcecode").value;
	document.getElementById("messagebox").value="";
    // addMessage("컴파일 중....\n");
     
     scanner();	
		
	for(curTokNo=0;curTokNo<tokens.length;curTokNo++){
	    if(isNaN(tokens[curTokNo])&&tokens[curTokNo]!='('){
			addMessage(tokens[curTokNo]);
		}else if(isNaN(tokens[curTokNo])==false||tokens[curTokNo]=='('){
			addMessage(mathparser());
			addMessage(tokens[curTokNo]);
		}
	}
     
     curTokNo=0;
}

function error_code1(){
	addMessage("컴파일오류 코드 1 ; 식이 잘못 되었습니다.\n다시 한번 확인을 부탁드립니다.\n 이 오류메세지 끝 ");
}

function error_code2(){
	addMessage("컴파일 에러 코드2 ; 괄호가 닫히지 않았습니다.\n다시 한번 확인을 부탁드립니다.\n 이 오류메세지 끝")	
}

function mathparser(){
	return expr();
}

var curTokNo=0;

function consumeToken()
{
	++curTokNo;
}

function tok(){
	if(curTokNo>=tokens.length) return "";
	return tokens[curTokNo];
}

function expr(){ // expr -> term (('+' | '-') term)*
	var r;
	r=term();
	while(tok()=='+' || tok()=='-'){
		if(tok()=='+'){
			consumeToken();
			r+=term();
		}else if(tok()=='-'){
			consumeToken();
			r-=term();
		}else{
			error_code1();
		}
	}
	return r;
} 
function term(){
	var r;
	r=factor();
	while(tok()=='*' || tok()=='/'){
		if(tok()=='*'){
			consumeToken();
			r*=factor();
		}else if(tok()=='/'){
			consumeToken();
			r/=factor();
		}else{
			error_code1();
		}
	}
	return r;
}
function factor(){ // factor -> NUMBER | '(' expr ')'
	var r;
	if(isNaN(tok())==true){ // '(' expr ')'
		if(tok()=='('){
			consumeToken();
			r=expr();
			if(tok()==')'){
				consumeToken();
				return r;
			}else{
				error_code1();
			}
		}else if(isNaN(tok())==true){
			error_code1();
		}
	}else{ // NUMBER
		r=tok();
		consumeToken();
		return r;
	}
}
function dump_token(){
    var su;
    for(var i=0;i<tokens.length+1;i++){
        addMessage(tokens[i]);
    }
}
function addMessage(msg){
    document.getElementById("messagebox").value+=msg;
    //document.getElementById("messagebox").value=document.getElementById("messagebox").value+"\n";
}

var fontsize=15;

function ZoomIn(){
	fontsize++;
	document.getElementById("sourcecode").style.fontSize=fontsize+"pt";
	document.getElementById("messagebox").style.fontSize=fontsize+"pt";
}

function ZoomOut(){
	fontsize--;
	document.getElementById("sourcecode").style.fontSize=fontsize+"pt";
	document.getElementById("messagebox").style.fontSize=fontsize+"pt";
}

function onClickDelete(){
	if(confirm("내용을 모두 지우겠습니까?")){
		document.getElementById("sourcecode").value="";
		document.getElementById("messagebox").value="";
	}
}